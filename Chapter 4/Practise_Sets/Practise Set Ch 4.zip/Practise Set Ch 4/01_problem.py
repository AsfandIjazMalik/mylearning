# 01 Problem

# Write a program to store seven fruits in a list entered by the user.

fruits = []

f1 = input("Enter the name of Fruit 1: ")
fruits.append(f1)
f2 = input("Enter the name of Fruit 2: ")
fruits.append(f2)
f3 = input("Enter the name of Fruit 3: ")
fruits.append(f3)
f4 = input("Enter the name of Fruit 4: ")
fruits.append(f4)
f5 = input("Enter the name of Fruit 5: ")
fruits.append(f5)
f6 = input("Enter the name of Fruit 6: ")
fruits.append(f6)
f7 = input("Enter the name of Fruit 7: ")
fruits.append(f7)

print(fruits)

