# 03 Problem
# Check that a tuple type cannot be changed in python.

li = (1 , 2, "Asfand")
li[2] = "Ijaz MAlik"