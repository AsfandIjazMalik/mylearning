# 03 Problem
# Write a program to sum a list with 4 numbers.

numz = [1,2,3,4]
print(sum(numz)) # sum() is buit in function which is used to sum the list 

#sum can be used with both LIST & TUPLE
nmu = (2,4,6,8)
print(sum(nmu)) # sum() is buit in function which is used to sum the list 


